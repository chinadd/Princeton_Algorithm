import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap; 
import java.io.*;


public class BruteCollinearPoints {
    int countSegments = 0;
    ArrayList<LineSegment> lineseg = new ArrayList<LineSegment>();
    
    public static boolean duplicates (Point[] points, int num ) {
        
    HashMap<Integer,Integer> map = new HashMap<Integer,Integer>();
    
    for ( int i = 0; i < num; ++i ) {
        int x = points[i].getx();
        int y = points[i].gety();
        
        if ( map.get(x) == null ) {
            map.put(x,y);         
        }
        else {
            if (map.get(x) == y) return true;
        }
    }
    return false;
}
    private static boolean isLine(final Point p, final Point q, final Point r,
                                  final Point s) {
        double slope = p.slopeTo(q);
        return p.slopeTo(r) == slope && p.slopeTo(s) == slope;
    }
    
    public BruteCollinearPoints(Point[] points) {
        // finds all line segments containing 4 points
        if ( points == null ) throw new java.lang.NullPointerException();
        
        for ( int i = 0 ; i < points.length ; i ++ ) {
            if (points[i] == null) throw new java.lang.NullPointerException();
        }
        
        if ( duplicates(points,points.length) ) throw new java.lang.IllegalArgumentException();
        
        int num = points.length;
        int max_x;
        int min_x;
        int max_x_y;
        int min_x_y;
        
        HashMap<Integer,Integer> m = new HashMap<Integer,Integer>();
        
        for ( int i = 0; i < num-3 ; i++ ) {
            max_x = points[i].getx();
            min_x = points[i].gety();
            m.put(points[i].getx(),points[i].gety());
            for (int j = i + 1; j < num - 2; j++) {
                if ( points[j].getx() > max_x ) max_x = points[j].getx();
                if ( points[j].getx() < min_x ) min_x = points[j].gety();
                m.put(points[j].getx(),points[j].gety());
                for (int k = j + 1; k < num - 1; k++) {
                    if ( points[k].getx() > max_x ) max_x = points[k].getx();
                    if ( points[k].getx() < min_x ) min_x = points[k].gety();
                    m.put(points[k].getx(),points[k].gety());
                    for (int l = k + 1; l < num; l++) {
                        if ( points[l].getx() > max_x ) max_x = points[l].getx();
                        if ( points[l].getx() < min_x ) min_x = points[l].gety();
                        m.put(points[l].getx(),points[l].gety());
                        if (isLine(points[i], points[j], points[k],
                                   points[l])) {
                            countSegments += 1;
                            max_x_y = m.get(max_x);
                            min_x_y = m.get(min_x);
                            Point e1 = new Point(max_x,max_x_y);
                            Point e2 = new Point(min_x,min_x_y);
                            lineseg.add(new LineSegment(e1,e2));
                        }
                    }
                }
            }
        }
        
    }     
   
    public int numberOfSegments() {
           // the number of line segments
           return countSegments;
    }
    public LineSegment[] segments() {
        // the line segments
        LineSegment[] linesegment = new LineSegment[countSegments];
        for (int i =0; i< countSegments; i++) {
            linesegment[i] = lineseg.get(i);
        }
        return linesegment;
    }
}