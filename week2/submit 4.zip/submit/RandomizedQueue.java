import java.util.Iterator;
import java.util.NoSuchElementException;


public class RandomizedQueue<Item> implements Iterable<Item> {
    
   private Node<Item> first;
   private int N;
   
   public RandomizedQueue() {
       // construct an empty randomized queue
       first = null;
       N = 0;
   }
   
   public boolean isEmpty() {
       // is the queue empty?
       return (first == null);
   }
   
   public int size() {
       // return the number of items on the queue
       return N;
   }
   
   public void enqueue(Item item) { 
       // add the item
       if (item == null) throw new NullPointerException();
       first = new Node<Item>(item, first);
       N += 1;
   }
   
   public Item dequeue() {
       
       // remove and return a random item
       if (first == null) {
           throw new NoSuchElementException();
       }
       int Min = 1; 
       int Max = N;
       int randomNum = (int)(Math.random() * ((Max - Min) + 1));
       Node<Item> curr = first;
       int count = 0;
       while (curr.next != null && count < randomNum-1) {
           curr = curr.next;
           count += 1;
       }
       if (count == randomNum-1) { 

           Node<Item> next = curr.next;
           Item d = next.data;
           curr.next = next. next;
           N -= 1;

           return d;
       } else {
           throw new NoSuchElementException();
       }
               
   } 
                        
   public Item sample()  {
       // return (but do not remove) a random item
       if (first == null) throw new NoSuchElementException();
       int Min = 1; 
       int Max = N;
       int randomNum = (int)(Math.random() * ((Max - Min) + 1));
       Node<Item> curr = first;
       int count = 0;
       while (curr.next != null && count < randomNum) {
           curr = curr.next;
           count += 1;
       }
       return curr.data;
   }
   
   private static class Node<Item>
   {
      private Item data;
      private Node<Item> next;

      public Node(Item data, Node<Item> next)
      {
         this.data = data;
         this.next = next;
      }
   }
   
   public Iterator<Item> iterator() {
       // return an iterator over items in order from front to end
       return new LinkedListIterator();
   }

   private class LinkedListIterator  implements Iterator<Item>
   {
      private Node<Item> nextNode;

      public LinkedListIterator()
      {
         nextNode = first;
      }

      public boolean hasNext()
      {
         return nextNode != null;
      }

      public Item next()
      {
         if (!hasNext()) throw new NoSuchElementException();
         Item res = nextNode.data;
         nextNode = nextNode.next;
         return res;
      }

      public void remove() { throw new UnsupportedOperationException(); }
   }
   public static void main(String[] args) {
       // unit testing
       RandomizedQueue<String> list = new RandomizedQueue <String>();
       list.enqueue("p");
       list.enqueue("a");
       list.enqueue("e");
       list.enqueue("h");
       
       System.out.println(list);
       
/*
       Iterator itr = list.iterator();
       while(itr.hasNext())
           System.out.print(itr.next() + " ");
       System.out.println();
 */      
       list.dequeue();
       
       for(Object x : list)
           System.out.print(x + " ");
       System.out.println();
   }
}